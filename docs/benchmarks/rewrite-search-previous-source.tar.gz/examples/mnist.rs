use std::time::Instant;

use clap::Parser;
use half::{bf16, f16};
use mnist::MnistBuilder;
use num_traits::Float;
use petgraph::graph::NodeIndex;
use rand::prelude::*;
use tnsr::data::DataLoader;
use tnsr::graph::TensorGraph;
use tnsr::nn;
use tnsr::nn::Model;
use tnsr::optimizer::Adam;
use tnsr::optimizer::SGD;
use tnsr::tensor::{Input, Parameter, TensorExpr};
use tnsr::{Executor, Runtime};

/// MNIST dataset downloader and loader utilities
mod mnist_loader {
    use std::fs;
    use std::io::{Read, Write};
    use std::path::{Path, PathBuf};

    use flate2::read::GzDecoder;

    /// Base URL for MNIST dataset files (Google Cloud Storage mirror)
    const MNIST_BASE_URL: &str = "https://storage.googleapis.com/cvdf-datasets/mnist";

    /// MNIST dataset file names
    const TRAIN_IMAGES: &str = "train-images-idx3-ubyte";
    const TRAIN_LABELS: &str = "train-labels-idx1-ubyte";
    const TEST_IMAGES: &str = "t10k-images-idx3-ubyte";
    const TEST_LABELS: &str = "t10k-labels-idx1-ubyte";

    /// Ensures all MNIST dataset files are downloaded and decompressed in the data directory.
    pub fn ensure_mnist_data(data_dir: &Path) -> Result<(), Box<dyn std::error::Error>> {
        // Create data directory if it doesn't exist
        fs::create_dir_all(data_dir)?;

        let files = [TRAIN_IMAGES, TRAIN_LABELS, TEST_IMAGES, TEST_LABELS];

        for file_name in &files {
            let file_path = data_dir.join(file_name);

            if file_path.exists() {
                println!("  ✓ {} already exists, skipping", file_name);
                continue;
            }

            println!("  Downloading {}...", file_name);
            let gz_file_name = format!("{}.gz", file_name);
            let url = format!("{}/{}", MNIST_BASE_URL, gz_file_name);

            // Download the .gz file
            let response = reqwest::blocking::get(&url)?;
            if !response.status().is_success() {
                return Err(format!(
                    "Failed to download {}: HTTP {}",
                    gz_file_name,
                    response.status()
                )
                .into());
            }

            let gz_bytes = response.bytes()?;

            println!("  Decompressing {}...", gz_file_name);

            // Decompress directly to file
            let mut decoder = GzDecoder::new(&gz_bytes[..]);
            let mut decompressed = Vec::new();
            decoder.read_to_end(&mut decompressed)?;

            // Write decompressed data to file
            let mut output_file = fs::File::create(&file_path)?;
            output_file.write_all(&decompressed)?;

            println!("  ✓ {} ready", file_name);
        }

        Ok(())
    }

    /// Returns the default data directory path (project_root/data)
    pub fn default_data_dir() -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("data")
    }
}

#[derive(Parser, Debug)]
struct Args {
    #[arg(long, default_value_t = 5)]
    epochs: usize,
    #[arg(long, default_value_t = 128)]
    batch_size: usize,
    #[arg(long, default_value_t = 0.05)]
    lr: f32,
    #[arg(long, default_value_t = 42)]
    seed: u64,
    /// Datatype: f32, f16, or bf16
    #[arg(long, default_value = "f32")]
    dtype: String,
    /// Optimizer: sgd or adam
    #[arg(long, default_value = "sgd")]
    optimizer: String,
    /// Model architecture: mlp or lenet
    #[arg(long, default_value = "mlp")]
    model: String,
}

fn one_hot<D: Float>(labels: &[u8], num_classes: usize) -> Vec<D> {
    let mut out = vec![D::zero(); labels.len() * num_classes];
    for (i, &y) in labels.iter().enumerate() {
        out[i * num_classes + (y as usize)] = D::one();
    }
    out
}

/// Enum wrapping the available optimizers so the training loop can be shared.
enum Opt<D: num_traits::Float> {
    Sgd(SGD),
    Adam(Adam<D>),
}

fn xavier_init<D: Float>(rng: &mut StdRng, fan_in: usize, fan_out: usize) -> Vec<D> {
    let limit = (6.0f32).sqrt() / ((fan_in + fan_out) as f32).sqrt();
    (0..fan_in * fan_out)
        .map(|_| D::from(rng.random_range(-limit..limit)).unwrap())
        .collect()
}

fn build_mlp_model<D>(
    batch: usize,
    w1: &Parameter<D>,
    b1: &Parameter<D>,
    w2: &Parameter<D>,
    b2: &Parameter<D>,
) -> Model<D>
where
    D: tnsr::tensor::DType + Default + 'static,
{
    // Inputs
    let images = Input::new("images", vec![batch, 784]);
    let labels = Input::new("labels", vec![batch, 10]);

    // Forward: h = relu(images @ w1 + b1), logits = h @ w2 + b2
    let h = nn::relu(nn::linear(images.clone(), w1.clone(), Some(b1.clone())));
    let logits = nn::linear(h, w2.clone(), Some(b2.clone()));
    let loss = nn::cross_entropy_one_hot_logits(logits.clone(), labels, 1);

    // Build model with named outputs
    let mut model = Model::new();
    model.add_output("logits", logits);
    model.add_output("loss", loss.clone());
    model.set_loss(loss);

    model
}

/// LeNet-5 style CNN.
///
/// conv(1->6, 5x5, pad 2) -> relu -> maxpool(2x2) ->
/// conv(6->16, 5x5, pad 0) -> relu -> maxpool(2x2) -> flatten ->
/// fc(400->120) -> relu -> fc(120->84) -> relu -> fc(84->10).
#[allow(clippy::too_many_arguments)]
fn build_lenet_model<D>(
    batch: usize,
    conv1_w: &Parameter<D>,
    conv2_w: &Parameter<D>,
    fc1_w: &Parameter<D>,
    fc1_b: &Parameter<D>,
    fc2_w: &Parameter<D>,
    fc2_b: &Parameter<D>,
    fc3_w: &Parameter<D>,
    fc3_b: &Parameter<D>,
) -> Model<D>
where
    D: tnsr::tensor::DType + Default + 'static,
{
    // Images arrive as a flat [batch, 784] buffer; interpret as [N, 1, 28, 28].
    let images = Input::new("images", vec![batch, 1, 28, 28]);
    let labels = Input::new("labels", vec![batch, 10]);

    // Conv1: 1->6, 5x5, stride 1, pad 2 -> [N, 6, 28, 28]
    let c1 = nn::relu(nn::conv2d(
        images.clone(),
        conv1_w.clone(),
        1,
        2,
        None::<TensorExpr<D>>,
    ));
    // MaxPool 2x2 stride 2 -> [N, 6, 14, 14]
    let p1 = nn::max_pool2d(c1, 2, 2);

    // Conv2: 6->16, 5x5, stride 1, pad 0 -> [N, 16, 10, 10]
    let c2 = nn::relu(nn::conv2d(p1, conv2_w.clone(), 1, 0, None::<TensorExpr<D>>));
    // MaxPool 2x2 stride 2 -> [N, 16, 5, 5]
    let p2 = nn::max_pool2d(c2, 2, 2);

    // Flatten -> [N, 400]
    let flat = nn::flatten(p2);

    // Fully connected head.
    let h1 = nn::relu(nn::linear(flat, fc1_w.clone(), Some(fc1_b.clone())));
    let h2 = nn::relu(nn::linear(h1, fc2_w.clone(), Some(fc2_b.clone())));
    let logits = nn::linear(h2, fc3_w.clone(), Some(fc3_b.clone()));

    let loss = nn::cross_entropy_one_hot_logits(logits.clone(), labels, 1);

    let mut model = Model::new();
    model.add_output("logits", logits);
    model.add_output("loss", loss.clone());
    model.set_loss(loss);

    model
}

fn main() {
    let args = Args::parse();

    // Initialize chrome tracing
    let guard =
        tnsr::init_chrome_tracing("mnist_trace.json").expect("Failed to initialize chrome tracing");
    println!("Chrome tracing initialized. Trace will be written to mnist_trace.json");

    let mut rng = StdRng::seed_from_u64(args.seed);

    // Ensure MNIST data is downloaded and decompressed
    println!("Checking MNIST dataset...");
    let data_dir = mnist_loader::default_data_dir();
    if let Err(e) = mnist_loader::ensure_mnist_data(&data_dir) {
        eprintln!("Failed to download MNIST dataset: {}", e);
        std::process::exit(1);
    }
    println!("MNIST dataset ready in {}", data_dir.display());

    // Load dataset from the mnist crate
    let ds_span = tracing::span!(tracing::Level::INFO, "load_mnist");
    let _enter = ds_span.enter();
    let mnist_data = MnistBuilder::new()
        .label_format_digit()
        .training_set_length(60_000)
        .validation_set_length(0)
        .test_set_length(10_000)
        .finalize();
    drop(_enter);
    println!("MNIST dataset loaded.");

    // Validate optimizer choice
    if !matches!(args.optimizer.as_str(), "sgd" | "adam") {
        eprintln!("Unknown optimizer '{}'. Use sgd or adam", args.optimizer);
        std::process::exit(1);
    }

    // Validate model choice
    if !matches!(args.model.as_str(), "mlp" | "lenet") {
        eprintln!("Unknown model '{}'. Use mlp or lenet", args.model);
        std::process::exit(1);
    }

    // Dispatch based on dtype
    match args.dtype.as_str() {
        "f32" => run_mnist::<f32>(&args, &mnist_data, &mut rng, Runtime::<f32>::new()),
        "f16" => run_mnist::<f16>(
            &args,
            &mnist_data,
            &mut rng,
            Runtime::Cpu(tnsr::SimpleExecutor::new()),
        ),
        "bf16" => run_mnist::<bf16>(
            &args,
            &mnist_data,
            &mut rng,
            Runtime::Cpu(tnsr::SimpleExecutor::new()),
        ),
        _ => {
            eprintln!("Unknown dtype '{}'. Use f32, f16, or bf16", args.dtype);
            std::process::exit(1);
        }
    }

    println!("\nTraining completed. Flushing chrome trace...");
    drop(guard);
    println!("Chrome trace written to mnist_trace.json");
    println!("Open chrome://tracing in Chrome browser and load the trace file to visualize timing");
}

/// Run `graph` over the test set and return (correct, seen) for argmax accuracy.
fn evaluate<D, G>(
    runtime: &mut Runtime<D>,
    graph: &TensorGraph<D, G>,
    loader: &mut DataLoader<D>,
    labels: &[u8],
    logits_idx: NodeIndex,
) -> (usize, usize)
where
    D: Float + Default + Send + Sync + 'static,
    TensorGraph<D, G>: Clone,
    TensorGraph<f32, G>: Clone,
{
    let mut correct = 0usize;
    let mut seen = 0usize;
    for (b, batch) in loader
        .iter()
        .expect("test data loader misconfigured")
        .enumerate()
    {
        let infer_span = tracing::span!(
            tracing::Level::TRACE,
            "infer_batch",
            idx = b,
            bs = batch.len()
        );
        let _ib = infer_span.enter();
        let indices = batch.indices().to_vec();
        runtime.execute(graph, batch.into_inputs()).unwrap();
        let logits = runtime.get_value(logits_idx).unwrap();

        for (i, &sample) in indices.iter().enumerate() {
            let row = &logits[i * 10..(i + 1) * 10];
            let pred = row
                .iter()
                .enumerate()
                .max_by(|a, b| a.1.partial_cmp(b.1).unwrap_or(std::cmp::Ordering::Equal))
                .map(|(idx, _)| idx)
                .unwrap_or(0);
            if pred as u8 == labels[sample] {
                correct += 1;
            }
        }
        seen += indices.len();
    }
    (correct, seen)
}

fn run_mnist<D>(args: &Args, mnist_data: &mnist::Mnist, rng: &mut StdRng, mut runtime: Runtime<D>)
where
    D: tnsr::tensor::DType + Float + Default + Send + Sync + 'static,
{
    println!("Running with dtype: {}", std::any::type_name::<D>());

    // Convert training images from u8 to D and normalize to [0, 1]
    let train_images: Vec<D> = mnist_data
        .trn_img
        .iter()
        .map(|&x| D::from(x as f32 / 255.0).unwrap())
        .collect();
    let train_labels_raw: Vec<u8> = mnist_data.trn_lbl.clone();
    let n_train = train_labels_raw.len();
    assert_eq!(n_train * 784, train_images.len());
    let train_labels_oh = one_hot::<D>(&train_labels_raw, 10);
    println!("Training samples: {n_train}");

    // Convert test images from u8 to D and normalize to [0, 1]
    let test_images: Vec<D> = mnist_data
        .tst_img
        .iter()
        .map(|&x| D::from(x as f32 / 255.0).unwrap())
        .collect();
    let test_labels_raw: Vec<u8> = mnist_data.tst_lbl.clone();
    let n_test = test_labels_raw.len();
    assert_eq!(n_test * 784, test_images.len());
    println!("Test samples: {n_test}");

    println!("Building computation graph...");
    let model = match args.model.as_str() {
        "lenet" => {
            let conv1_w = Parameter::new(xavier_init(rng, 25, 6), vec![6, 1, 5, 5]);
            let conv2_w = Parameter::new(xavier_init(rng, 150, 16), vec![16, 6, 5, 5]);
            let fc1_w = Parameter::new(xavier_init(rng, 400, 120), vec![400, 120]);
            let fc1_b = Parameter::new(vec![D::zero(); 120], vec![1, 120]);
            let fc2_w = Parameter::new(xavier_init(rng, 120, 84), vec![120, 84]);
            let fc2_b = Parameter::new(vec![D::zero(); 84], vec![1, 84]);
            let fc3_w = Parameter::new(xavier_init(rng, 84, 10), vec![84, 10]);
            let fc3_b = Parameter::new(vec![D::zero(); 10], vec![1, 10]);
            build_lenet_model(
                args.batch_size,
                &conv1_w,
                &conv2_w,
                &fc1_w,
                &fc1_b,
                &fc2_w,
                &fc2_b,
                &fc3_w,
                &fc3_b,
            )
        }
        _ => {
            let w1 = Parameter::new(xavier_init(rng, 784, 128), vec![784, 128]);
            let b1 = Parameter::new(vec![D::zero(); 128], vec![1, 128]);
            let w2 = Parameter::new(xavier_init(rng, 128, 10), vec![128, 10]);
            let b2 = Parameter::new(vec![D::zero(); 10], vec![1, 10]);
            build_mlp_model(args.batch_size, &w1, &b1, &w2, &b2)
        }
    };
    println!("Using model: {}", args.model);
    let logits_idx = model.get_output("logits").expect("logits output");
    let loss_idx = model.loss().expect("loss node");

    // Augment graph with gradient computation nodes (consumes the graph)
    let grad_graph = model.into_graph().with_gradients(loss_idx);
    let mut opt = match args.optimizer.as_str() {
        "adam" => Opt::Adam(Adam::new(args.lr)),
        _ => Opt::Sgd(SGD::new(args.lr)),
    };
    println!("Using optimizer: {}", args.optimizer);
    println!("Using backend: {:?}", runtime.backend());

    // Data loaders handle shuffling, slicing, and padding batches. The test
    // loader fills the labels input with zeros since evaluation only reads
    // logits.
    let mut train_loader = DataLoader::new(n_train)
        .with("images", &train_images, 784)
        .with("labels", &train_labels_oh, 10)
        .batch_size(args.batch_size)
        .shuffle(args.seed)
        .pad_last();
    let mut test_loader = DataLoader::new(n_test)
        .with("images", &test_images, 784)
        .with_fill("labels", 10, D::zero())
        .batch_size(args.batch_size)
        .pad_last();

    // Training loop
    println!("Starting training for {} epochs...", args.epochs);
    let batches_per_epoch = n_train.div_ceil(args.batch_size);
    let training_start = Instant::now();
    for epoch in 0..args.epochs {
        let epoch_start = Instant::now();
        let epoch_span = tracing::span!(
            tracing::Level::INFO,
            "epoch",
            idx = epoch + 1,
            batches = batches_per_epoch,
            lr = args.lr,
            batch_size = args.batch_size
        );
        let _eg = epoch_span.enter();

        // Training phase
        {
            let mut epoch_loss = D::zero();
            let mut steps = 0usize;

            for (b, batch) in train_loader
                .iter()
                .expect("training data loader misconfigured")
                .enumerate()
            {
                let batch_span =
                    tracing::span!(tracing::Level::TRACE, "batch", idx = b, bs = batch.len());
                let _bg = batch_span.enter();

                // Forward pass computes both loss and gradients
                let loss_value = runtime.execute(&grad_graph, batch.into_inputs()).unwrap();
                let grads = runtime.get_gradients(&grad_graph);

                if steps.is_multiple_of(50)
                    && let Some(&lv) = loss_value.first()
                {
                    epoch_loss = epoch_loss + lv;
                }
                let opt_span = tracing::span!(tracing::Level::TRACE, "optimizer_step");
                let _og = opt_span.enter();
                match &mut opt {
                    Opt::Sgd(o) => o.step(&grad_graph, &grads),
                    Opt::Adam(o) => o.step(&grad_graph, &grads),
                }
                drop(_og);
                steps += 1;
            }
            let avg_loss_f32 = (epoch_loss / D::from(steps.max(1) as f32 / 50.0).unwrap())
                .to_f32()
                .unwrap_or(0.0);
            println!(
                "epoch {} avg loss ~ {:.4}, execution time {:.2}",
                epoch + 1,
                avg_loss_f32,
                epoch_start.elapsed().as_secs_f32()
            );
        }

        // Evaluate on current epoch
        let eval_span = tracing::span!(
            tracing::Level::INFO,
            "evaluate",
            test_batches = n_test.div_ceil(args.batch_size)
        );
        let _ev = eval_span.enter();
        let (correct, seen) = evaluate(
            &mut runtime,
            &grad_graph,
            &mut test_loader,
            &test_labels_raw,
            logits_idx,
        );
        let acc = correct as f32 / seen as f32;
        println!("test accuracy: {:.2}% ({}/{})", acc * 100.0, correct, seen);
        println!("total time {:.2}s", training_start.elapsed().as_secs_f32());
    }

    // Final inference graph evaluation
    let infer_graph = grad_graph.without_gradients();
    println!("\nFinal evaluation using inference-only graph...");
    let final_eval_span = tracing::span!(tracing::Level::INFO, "final_evaluation");
    let _fev = final_eval_span.enter();
    let (correct, seen) = evaluate(
        &mut runtime,
        &infer_graph,
        &mut test_loader,
        &test_labels_raw,
        logits_idx,
    );
    let final_acc = correct as f32 / seen as f32;
    println!(
        "Final test accuracy (inference graph): {:.2}% ({}/{})",
        final_acc * 100.0,
        correct,
        seen
    );
}
