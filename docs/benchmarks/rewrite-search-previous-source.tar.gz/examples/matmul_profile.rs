//! Focused matmul ablations. Run with CUDA enabled; all timings are microseconds.
//! Arguments: [batch|flat] [epilogue stage 0..3] [B] [M] [K] [N] [measure|trace] [f32|f16|bf16].
//! Stages: matmul, +bias, +ReLU, +residual. Flat merges B and M for shared weights.
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Instant;

use anyhow::{Context, Result};
use cudarc::driver::{
    CudaContext, CudaFunction, CudaSlice, CudaStream, DevicePtr, LaunchConfig, PushKernelArg, sys,
};
use cudarc::nvrtc::Ptx;
use num_traits::{Float, ToPrimitive, cast};
use tnsr::graph::{NodeIndex, TensorGraph, TensorGraphNode};
use tnsr::ptx::{
    PtxExecutor, PtxFusionPolicy, PtxPlanAction,
    types::{BF16, CudaDType, F16, F32},
};
use tnsr::tensor::{Parameter, TensorExpr};
use tnsr::tile::{MatMulPipeline, MatMulPrecision, MatMulSharedLayout};
use tnsr::{Executor, SimpleExecutor};

struct Launch {
    function: CudaFunction,
    config: LaunchConfig,
    pointers: Vec<u64>,
}

fn submit(stream: &Arc<CudaStream>, launches: &[Launch]) -> Result<()> {
    for launch in launches {
        let mut builder = stream.launch_builder(&launch.function);
        for pointer in &launch.pointers {
            builder.arg(pointer);
        }
        // SAFETY: Every pointer comes from a live, preallocated buffer. Inputs
        // were uploaded and synchronized before launch, all launches use this
        // stream in dependency order, and buffers stay alive until synchronization.
        unsafe { builder.launch(launch.config) }.context("resident matmul launch failed")?;
    }
    Ok(())
}

fn percentile(values: &mut [f64], fraction: usize) -> f64 {
    values.sort_by(f64::total_cmp);
    values[(values.len() - 1) * fraction / 100]
}

fn main() -> Result<()> {
    match std::env::args().nth(8).as_deref().unwrap_or("f32") {
        "f32" => profile::<F32>(),
        "f16" => profile::<F16>(),
        "bf16" => profile::<BF16>(),
        dtype => anyhow::bail!("unsupported profiling dtype {dtype}"),
    }
}

fn profile<D: CudaDType>() -> Result<()> {
    let scalar = |value: f32| -> Result<D::HostType> {
        cast(value).context("profiling value is not representable")
    };
    let element_bytes = std::mem::size_of::<D::HostType>();
    let args: Vec<String> = std::env::args().skip(1).collect();
    let flat = args.first().is_some_and(|argument| argument == "flat");
    let number = |position: usize, default: usize| -> Result<usize> {
        args.get(position)
            .map(|value| value.parse().context("invalid dimension/stage"))
            .unwrap_or(Ok(default))
    };
    let stage = number(1, 3)?;
    let (batches, m, k, n) = (
        number(2, 2)?,
        number(3, 128)?,
        number(4, 256)?,
        number(5, 768)?,
    );
    anyhow::ensure!(
        stage <= 3 && [batches, m, k, n].iter().all(|&extent| extent > 0),
        "invalid stage or zero dimension"
    );
    let trace = args.get(6).is_some_and(|mode| mode == "trace");
    let transpose_lhs = std::env::var_os("TNSR_PROFILE_TRANSPOSE_LHS").is_some();
    let transpose_rhs = std::env::var_os("TNSR_PROFILE_TRANSPOSE_RHS").is_some();
    let input_shape = if transpose_lhs {
        if flat {
            vec![k, batches * m]
        } else {
            vec![batches, k, m]
        }
    } else if flat {
        vec![batches * m, k]
    } else {
        vec![batches, m, k]
    };
    let output_shape = if flat {
        vec![batches * m, n]
    } else {
        vec![batches, m, n]
    };
    let input = Parameter::new(
        (0..batches * m * k)
            .map(|index| scalar((index % 29) as f32 / 29.0 - 0.5))
            .collect::<Result<Vec<_>>>()?,
        input_shape,
    );
    let weight = Parameter::new(
        (0..k * n)
            .map(|index| scalar((index % 31) as f32 / 31.0 - 0.5))
            .collect::<Result<Vec<_>>>()?,
        if transpose_rhs {
            vec![n, k]
        } else {
            vec![k, n]
        },
    );
    let lhs = if transpose_lhs {
        TensorExpr::from(input).transpose()
    } else {
        TensorExpr::from(input)
    };
    let rhs = if transpose_rhs {
        TensorExpr::from(weight).transpose()
    } else {
        TensorExpr::from(weight)
    };
    let mut expression = lhs.matmul(rhs);
    if stage >= 1 {
        expression = expression + TensorExpr::from(Parameter::new(vec![scalar(0.1)?; n], vec![n]));
    }
    if stage >= 2 {
        expression = expression.relu();
    }
    if stage >= 3 {
        expression = expression
            + TensorExpr::from(Parameter::new(
                vec![scalar(0.05)?; batches * m * n],
                output_shape,
            ));
    }
    let graph: TensorGraph<D::HostType> = expression.into();
    let mut executor = PtxExecutor::<D>::try_new_for_dtype()?;
    if std::env::var_os("TNSR_PROFILE_TF32X3").is_some() {
        executor.set_matmul_precision(MatMulPrecision::Tf32x3);
    }
    if std::env::var("TNSR_PROFILE_STRICT").is_ok() {
        executor.set_matmul_precision(MatMulPrecision::StrictF32);
    }
    let layout = match std::env::var("TNSR_PROFILE_SHARED_LAYOUT")
        .as_deref()
        .unwrap_or("auto")
    {
        "auto" => MatMulSharedLayout::Auto,
        "contiguous" => MatMulSharedLayout::Contiguous,
        "padded" => MatMulSharedLayout::Padded,
        "swizzled" => MatMulSharedLayout::Swizzled,
        other => anyhow::bail!("unsupported shared layout {other}"),
    };
    executor.set_matmul_shared_layout(layout);
    executor.set_matmul_pipeline(
        match std::env::var("TNSR_PROFILE_PIPELINE")
            .as_deref()
            .unwrap_or("auto")
        {
            "auto" => MatMulPipeline::Auto,
            "sync" => MatMulPipeline::Synchronous,
            "double" => MatMulPipeline::DoubleBuffered,
            other => anyhow::bail!("unsupported matmul pipeline {other}"),
        },
    );
    if std::env::var("TNSR_PROFILE_FUSION").as_deref() == Ok("greedy") {
        executor.set_fusion_policy(PtxFusionPolicy::Greedy);
    }
    executor.compile_owned(graph.clone())?;
    let description = executor.describe_plan(&graph)?;
    let source = executor.module_source().context("missing PTX")?;
    if let Ok(path) = std::env::var("TNSR_PROFILE_PTX") {
        std::fs::write(path, &source)?;
    }
    let actual = executor.execute_compiled(&graph, HashMap::new())?;
    let plan = executor
        .execution_plan()
        .context("missing execution plan")?;
    if std::env::var("TNSR_PROFILE_FUSION_DIAGNOSTICS").as_deref() == Ok("1") {
        eprint!("{}", plan.describe_fusion());
        eprintln!(
            "fusion_selection_us={:.3}",
            executor
                .compile_metrics()
                .fusion_selection_time
                .as_secs_f64()
                * 1e6
        );
    }
    let device = CudaContext::new(0)?;
    let stream = device.default_stream();
    // Optional PTX-only experiment: resident timings use this module; executor
    // timings continue to measure the unmodified graph compilation.
    let resident_source = match std::env::var("TNSR_PROFILE_OVERRIDE_PTX") {
        Ok(path) => std::fs::read_to_string(path)?,
        Err(_) => source,
    };
    let module = device.load_module(Ptx::from_src(resident_source))?;
    let mut storage: HashMap<NodeIndex, CudaSlice<D::HostType>> = HashMap::new();
    let mut aliases = HashMap::new();
    let names: Vec<Option<&str>> = description
        .lines()
        .skip(1)
        .map(|line| {
            line.split("action=kernel ")
                .nth(1)
                .and_then(|name| name.split_whitespace().next())
        })
        .collect();
    anyhow::ensure!(
        names.len() == plan.steps().len(),
        "plan description length mismatch"
    );
    let mut launches = Vec::new();
    for (step, name) in plan.steps().iter().zip(names) {
        if step.action == PtxPlanAction::Upload {
            let data = match &graph[step.node] {
                TensorGraphNode::Parameter { data, .. } => data
                    .lock()
                    .map_err(|_| anyhow::anyhow!("parameter lock poisoned"))?
                    .clone(),
                TensorGraphNode::Constant { data, .. } => data.as_ref().clone(),
                _ => anyhow::bail!("unsupported upload"),
            };
            storage.insert(step.node, stream.memcpy_stod(&data)?);
            continue;
        }
        if step.action == PtxPlanAction::VirtualView {
            for output in &step.virtual_outputs {
                aliases.insert(step.node, output.source);
            }
            continue;
        }
        let name = name.context("unsupported physical action in profiling graph")?;
        for (&output, shape) in step.outputs.iter().zip(&step.output_shapes) {
            storage.insert(
                output,
                stream.alloc_zeros::<D::HostType>(shape.iter().product())?,
            );
        }
        let pointer = |node: &NodeIndex| -> Result<u64> {
            let node = aliases.get(node).unwrap_or(node);
            let buffer = storage.get(node).context("resident buffer unavailable")?;
            Ok(buffer.device_ptr(&stream).0)
        };
        let inputs = step
            .inputs
            .iter()
            .map(pointer)
            .collect::<Result<Vec<_>>>()?;
        let outputs = step
            .outputs
            .iter()
            .map(pointer)
            .collect::<Result<Vec<_>>>()?;
        let function = module.load_function(name)?;
        if step.action == PtxPlanAction::Kernel
            && matches!(graph[step.node], TensorGraphNode::MatMul { .. })
        {
            let shape = &step.shape;
            let rows = shape[shape.len() - 2];
            let cols = shape[shape.len() - 1];
            let count: usize = shape[..shape.len() - 2].iter().product();
            let schedule = plan
                .matmul_schedules()
                .get(&step.node)
                .context("missing schedule")?;
            // This harness intentionally uses rank-two shared B for every case.
            for batch in 0..count {
                launches.push(Launch {
                    function: function.clone(),
                    config: LaunchConfig {
                        grid_dim: (
                            u32::try_from(cols.div_ceil(schedule.block_tile.n))?,
                            u32::try_from(rows.div_ceil(schedule.block_tile.m))?,
                            1,
                        ),
                        block_dim: schedule.block_threads,
                        shared_mem_bytes: 0,
                    },
                    pointers: vec![
                        inputs[0] + u64::try_from(batch * rows * k * element_bytes)?,
                        inputs[1],
                        outputs[0] + u64::try_from(batch * rows * cols * element_bytes)?,
                    ],
                });
            }
        } else {
            let config = if let PtxPlanAction::MatMulRegion(region_id) = step.action {
                let schedule = plan.matmul_regions()[region_id].schedule;
                let shape = &step.shape;
                LaunchConfig {
                    grid_dim: (
                        u32::try_from(shape[shape.len() - 1].div_ceil(schedule.block_tile.n))?,
                        u32::try_from(shape[shape.len() - 2].div_ceil(schedule.block_tile.m))?,
                        u32::try_from(shape[..shape.len() - 2].iter().product::<usize>())?,
                    ),
                    block_dim: schedule.block_threads,
                    shared_mem_bytes: 0,
                }
            } else {
                LaunchConfig::for_num_elems(u32::try_from(step.shape.iter().product::<usize>())?)
            };
            launches.push(Launch {
                function,
                config,
                pointers: inputs.into_iter().chain(outputs).collect(),
            });
        }
    }
    stream.synchronize()?;
    let repeats = if trace { 1 } else { 32 };
    for _ in 0..16 {
        submit(&stream, &launches)?;
    }
    stream.synchronize()?;
    let mut resident = Vec::new();
    for _ in 0..20 {
        let start = stream.record_event(Some(sys::CUevent_flags::CU_EVENT_DEFAULT))?;
        for _ in 0..repeats {
            submit(&stream, &launches)?;
        }
        let end = stream.record_event(Some(sys::CUevent_flags::CU_EVENT_DEFAULT))?;
        resident.push(f64::from(start.elapsed_ms(&end)?) * 1000.0 / f64::from(repeats));
    }
    let output = plan.graph_output().context("missing output")?;
    let chosen_schedule = plan.matmul_regions().first().map(|region| region.schedule);
    let resident_actual =
        stream.memcpy_dtov(storage.get(&output).context("missing output storage")?)?;
    let reference = if trace {
        actual.clone()
    } else {
        SimpleExecutor::<D::HostType>::new().execute(&graph, HashMap::new())?
    };
    let error = resident_actual.iter().zip(&reference).try_fold(
        0.0f32,
        |maximum, (&a, &b)| -> Result<f32> {
            Ok(maximum.max(
                (a.to_f32().context("invalid output")?
                    - b.to_f32().context("invalid reference")?)
                .abs(),
            ))
        },
    )?;
    let reference_scale = reference
        .iter()
        .try_fold(1.0f32, |maximum, value| -> Result<f32> {
            Ok(maximum.max(value.to_f32().context("invalid reference")?.abs()))
        })?;
    let tolerance = 1e-2
        + D::HostType::epsilon()
            .to_f32()
            .context("invalid dtype epsilon")?
            * reference_scale;
    anyhow::ensure!(
        error <= tolerance && resident_actual.len() == reference.len(),
        "resident numerical mismatch {error}"
    );
    let mut end_to_end = Vec::new();
    if !trace {
        for _ in 0..3 {
            executor.execute_compiled(&graph, HashMap::new())?;
        }
        for _ in 0..20 {
            let started = Instant::now();
            for _ in 0..5 {
                executor.execute_compiled(&graph, HashMap::new())?;
            }
            end_to_end.push(started.elapsed().as_secs_f64() * 1e6 / 5.0);
        }
    } else {
        end_to_end.push(0.0);
    }
    let compile = executor.compile_metrics();
    let execution = executor.execution_metrics();
    println!("SCHEDULE,{:?}", chosen_schedule);
    println!(
        "METRICS,{:.3},{:.3},{},{}",
        compile.compile_time.as_secs_f64() * 1e6,
        compile.index_optimization_time.as_secs_f64() * 1e6,
        execution.kernel_launches,
        execution.intermediate_materialized_bytes
    );
    println!(
        "RESULT,{},{stage},{batches},{m},{k},{n},{},{:.3},{:.3},{:.3},{:.3},{:.3},{:.3},{error}",
        if flat { "flat" } else { "batch" },
        launches.len(),
        percentile(&mut resident, 50),
        percentile(&mut resident, 10),
        percentile(&mut resident, 90),
        percentile(&mut end_to_end, 50),
        percentile(&mut end_to_end, 10),
        percentile(&mut end_to_end, 90)
    );
    Ok(())
}
