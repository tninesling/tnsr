//! Share pure index expressions and bind them in the earliest lexical scope that
//! contains all dependencies. No loads, floating-point operations, or barriers
//! move. Wrapping arithmetic is total after divisor/shift validation, so empty
//! loops and predicated edge loads are safe even when bindings move outward.
use std::collections::{BTreeMap, BTreeSet, HashMap};

use anyhow::Result;

use super::{Block, Expr, Stmt, TileIR};

type Scope = Vec<usize>;

fn roots(stmt: &mut Stmt) -> Vec<&mut Expr> {
    match stmt {
        Stmt::LetIndex { value, .. } => vec![value],
        Stmt::LoadIndex { index, .. } => vec![index],
        Stmt::Load {
            row_offset,
            col_offset,
            ..
        }
        | Stmt::Store {
            row_offset,
            col_offset,
            ..
        } => vec![row_offset, col_offset],
        Stmt::LoadGlobalToSharedPredicated {
            element_index,
            row,
            col,
            tile_row,
            tile_col,
            ..
        }
        | Stmt::AsyncCopy {
            element_index,
            row,
            col,
            tile_row,
            tile_col,
            ..
        } => vec![element_index, row, col, tile_row, tile_col],
        Stmt::LoadGlobalPredicated {
            element_index,
            row,
            col,
            ..
        }
        | Stmt::StoreGlobalPredicated {
            element_index,
            row,
            col,
            ..
        } => vec![element_index, row, col],
        Stmt::ConvertLayout {
            coordinates: Some((row, col)),
            ..
        } => vec![row, col],
        Stmt::ForLoop {
            start,
            end,
            carries,
            ..
        } => {
            let mut roots = vec![start, end];
            for carry in carries {
                roots.extend(carry.initial.index_roots());
            }
            roots
        }
        Stmt::LoadScalar { index, .. } | Stmt::StoreScalar { index, .. } => vec![index],
        Stmt::SetScalar { value, .. } => value.index_roots(),
        Stmt::If { condition, .. } => condition.index_roots(),
        Stmt::SelectSharedStage { stage, .. } => vec![stage],
        _ => Vec::new(),
    }
}

fn children(expr: &Expr) -> Vec<&Expr> {
    match expr {
        Expr::Add(a, b) | Expr::Sub(a, b) | Expr::Mul(a, b) => vec![a, b],
        Expr::FloorDiv(a, _) | Expr::Mod(a, _) | Expr::ShiftRight(a, _) | Expr::BitAnd(a, _) => {
            vec![a]
        }
        _ => Vec::new(),
    }
}

fn normalize(block: &mut Block, cache: &mut HashMap<Expr, Expr>) -> Result<()> {
    for stmt in &mut block.stmts {
        for root in roots(stmt) {
            let value = if let Some(value) = cache.get(root) {
                value.clone()
            } else {
                let value = super::index_egraph::normalize_address(root)?;
                cache.insert(root.clone(), value.clone());
                value
            };
            *root = value;
        }
        if let Stmt::ForLoop { body, .. } | Stmt::If { body, .. } = stmt {
            normalize(body, cache)?;
        }
    }
    Ok(())
}

#[derive(Default)]
struct Usage {
    scopes: Vec<Scope>,
    locations: Vec<Scope>,
}

fn census(
    expr: &Expr,
    scope: &Scope,
    position: usize,
    usage: &mut BTreeMap<Expr, Usage>,
    names: &mut BTreeSet<String>,
) {
    if let Expr::Var(name) = expr {
        names.insert(name.clone());
    }
    let entry = usage.entry(expr.clone()).or_default();
    entry.scopes.push(scope.clone());
    let mut location = scope.clone();
    location.push(position);
    entry.locations.push(location);
    for child in children(expr) {
        census(child, scope, position, usage, names);
    }
}

fn collect(
    block: &mut Block,
    scope: &Scope,
    usage: &mut BTreeMap<Expr, Usage>,
    variables: &mut HashMap<String, Option<Scope>>,
    names: &mut BTreeSet<String>,
) {
    for (index, stmt) in block.stmts.iter_mut().enumerate() {
        for root in roots(stmt) {
            census(root, scope, index, usage, names);
        }
        // Loaded indices reserve their names but remain opaque to hoisting;
        // dependent expressions stay after the load in their original scope.
        if let Stmt::LetIndex { name, .. } | Stmt::LoadIndex { name, .. } = stmt {
            names.insert(name.clone());
        }
        if let Stmt::ForLoop { loop_var, body, .. } = stmt {
            names.insert(loop_var.clone());
            let mut inner = scope.clone();
            inner.push(index);
            // Repeated/shadowed names are conservatively excluded from hoisting.
            variables
                .entry(loop_var.clone())
                .and_modify(|value| *value = None)
                .or_insert(Some(inner.clone()));
            collect(body, &inner, usage, variables, names);
        } else if let Stmt::If { body, .. } = stmt {
            let mut inner = scope.clone();
            inner.push(index);
            collect(body, &inner, usage, variables, names);
        }
    }
}

fn dependency_scope(expr: &Expr, variables: &HashMap<String, Option<Scope>>) -> Option<Scope> {
    let mut scope = match expr {
        Expr::Var(name) => variables.get(name)?.clone()?,
        _ => Vec::new(),
    };
    for child in children(expr) {
        let child_scope = dependency_scope(child, variables)?;
        if scope.starts_with(&child_scope) {
        } else if child_scope.starts_with(&scope) {
            scope = child_scope;
        } else {
            return None;
        }
    }
    Some(scope)
}

fn height(expr: &Expr) -> usize {
    1 + children(expr).into_iter().map(height).max().unwrap_or(0)
}

struct Binding {
    name: String,
    scope: Scope,
    position: usize,
}

fn substitute(expr: &mut Expr, bindings: &BTreeMap<Expr, Binding>) {
    if let Some(binding) = bindings.get(expr) {
        *expr = Expr::Var(binding.name.clone());
        return;
    }
    substitute_children(expr, bindings);
}
fn substitute_children(expr: &mut Expr, bindings: &BTreeMap<Expr, Binding>) {
    match expr {
        Expr::Add(a, b) | Expr::Sub(a, b) | Expr::Mul(a, b) => {
            substitute(a, bindings);
            substitute(b, bindings);
        }
        Expr::FloorDiv(a, _) | Expr::Mod(a, _) | Expr::ShiftRight(a, _) | Expr::BitAnd(a, _) => {
            substitute(a, bindings)
        }
        _ => {}
    }
}

fn place(block: &mut Block, scope: &Scope, bindings: &BTreeMap<Expr, Binding>) {
    let mut definitions: Vec<_> = bindings
        .iter()
        .filter(|(_, binding)| binding.scope == *scope)
        .collect();
    // Same-scope children are defined first; parent-scope bindings already dominate.
    definitions.sort_by_key(|(expr, binding)| (binding.position, height(expr), *expr));
    let mut definitions = definitions.into_iter().peekable();
    let mut result = Vec::new();
    for (index, mut stmt) in std::mem::take(&mut block.stmts).into_iter().enumerate() {
        // Define shared expressions immediately before their first consumer,
        // rather than making epilogue and later staging addresses live across
        // the entire kernel. Dependencies' original uses include their parents,
        // so height order also dominates same-position dependent bindings.
        while definitions
            .peek()
            .is_some_and(|(_, binding)| binding.position == index)
        {
            let Some((expr, binding)) = definitions.next() else {
                break;
            };
            let mut value = expr.clone();
            substitute_children(&mut value, bindings);
            result.push(Stmt::LetIndex {
                name: binding.name.clone(),
                value,
            });
        }
        for root in roots(&mut stmt) {
            substitute(root, bindings);
        }
        if let Stmt::ForLoop { body, .. } | Stmt::If { body, .. } = &mut stmt {
            let mut inner = scope.clone();
            inner.push(index);
            place(body, &inner, bindings);
        }
        result.push(stmt);
    }
    block.stmts = result;
}

impl TileIR {
    pub(crate) fn normalize_indices(&mut self) -> Result<()> {
        normalize(&mut self.body, &mut HashMap::new())
    }

    /// Normalize and share integer index expressions before backend lowering.
    pub fn optimize_indices(&mut self) -> Result<()> {
        // Explicitly hoisting every staging address increases register pressure
        // in large synchronous BF16 register tiles. Keep normalized expressions
        // local there, allowing the backend to rematerialize cheap arithmetic.
        fn rematerialize(block: &Block) -> bool {
            block.stmts.iter().any(|stmt| match stmt {
                Stmt::MatMul { schedule, .. } => {
                    schedule.storage_dtype == super::DType::BF16
                        && schedule.warp_fragments != (1, 1)
                        && schedule.pipeline_stages == 1
                }
                Stmt::ForLoop { body, .. } | Stmt::If { body, .. } => rematerialize(body),
                _ => false,
            })
        }
        self.optimize_indices_with_sharing(!rematerialize(&self.body))
    }

    pub(crate) fn optimize_indices_with_sharing(&mut self, share: bool) -> Result<()> {
        self.normalize_indices()?;
        if !share {
            return Ok(());
        }
        let (mut usage, mut variables, mut names) =
            (BTreeMap::new(), HashMap::new(), BTreeSet::new());
        collect(
            &mut self.body,
            &Vec::new(),
            &mut usage,
            &mut variables,
            &mut names,
        );
        let mut bindings = BTreeMap::new();
        let mut serial = 0;
        for (expr, usage) in usage {
            // Primitive index reads are cheap and may be rematerialized by the
            // backend. Binding them can extend register lifetimes without sharing
            // any arithmetic; share composite expressions instead.
            if matches!(
                expr,
                Expr::Const(_)
                    | Expr::Var(_)
                    | Expr::BlockIdx(_)
                    | Expr::ThreadIdx(_)
                    | Expr::BlockDim(_)
            ) {
                continue;
            }
            let Some(scope) = dependency_scope(&expr, &variables) else {
                continue;
            };
            if !usage
                .scopes
                .iter()
                .all(|use_scope| use_scope.starts_with(&scope))
            {
                continue;
            }
            if usage.scopes.len() < 2
                && !usage
                    .scopes
                    .iter()
                    .any(|use_scope| use_scope.len() > scope.len())
            {
                continue;
            }
            let name = loop {
                let name = format!("__tnsr_index_{serial}");
                serial += 1;
                if names.insert(name.clone()) {
                    break name;
                }
            };
            let position = usage
                .locations
                .iter()
                .map(|location| location[scope.len()])
                .min()
                .ok_or_else(|| anyhow::anyhow!("index binding has no consumer"))?;
            bindings.insert(
                expr,
                Binding {
                    name,
                    scope,
                    position,
                },
            );
        }
        place(&mut self.body, &Vec::new(), &bindings);
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tile::Dim;
    fn load(expr: Expr) -> Stmt {
        Stmt::Load {
            dest: crate::tile::TileVar(0),
            src_param: "x".into(),
            row_offset: expr,
            col_offset: Expr::Const(0),
        }
    }
    fn ir(stmts: Vec<Stmt>) -> TileIR {
        TileIR {
            kernel_name: "indices".into(),
            params: Vec::new(),
            shared_mem_bytes: 0,
            body: Block { stmts },
        }
    }
    fn evaluate(expr: &Expr, env: &HashMap<String, u64>) -> u64 {
        match expr {
            Expr::Const(v) => *v as u64,
            Expr::Var(name) => env[name],
            Expr::BlockIdx(_) => 7,
            Expr::ThreadIdx(_) => 1,
            Expr::BlockDim(_) => 16,
            Expr::Add(a, b) => evaluate(a, env).wrapping_add(evaluate(b, env)),
            Expr::Sub(a, b) => evaluate(a, env).wrapping_sub(evaluate(b, env)),
            Expr::Mul(a, b) => evaluate(a, env).wrapping_mul(evaluate(b, env)),
            Expr::FloorDiv(a, d) => evaluate(a, env) / *d as u64,
            Expr::Mod(a, d) => evaluate(a, env) % *d as u64,
            Expr::ShiftRight(a, d) => evaluate(a, env) >> d,
            Expr::BitAnd(a, d) => evaluate(a, env) & d,
        }
    }
    fn execute(block: &Block, env: &mut HashMap<String, u64>, offsets: &mut Vec<u64>) {
        let outer = env.clone();
        for stmt in &block.stmts {
            match stmt {
                Stmt::LetIndex { name, value } => {
                    env.insert(name.clone(), evaluate(value, env));
                }
                Stmt::Load { row_offset, .. } => offsets.push(evaluate(row_offset, env)),
                Stmt::ForLoop {
                    loop_var,
                    start,
                    end,
                    body,
                    ..
                } => {
                    for i in evaluate(start, env)..evaluate(end, env) {
                        env.insert(loop_var.clone(), i);
                        execute(body, env, offsets);
                    }
                }
                _ => {}
            }
        }
        *env = outer;
    }
    #[test]
    fn places_non_power_of_two_division_outside_nested_loops() {
        let batch = Expr::FloorDiv(Box::new(Expr::BlockIdx(Dim::Z)), 3);
        let outer = Expr::Var("outer".into()) * 4_usize;
        let address = batch.clone() + outer.clone() + Expr::Var("inner".into());
        let mut ir = ir(vec![Stmt::ForLoop {
            loop_var: "outer".into(),
            start: Expr::Const(0),
            end: Expr::Const(7),
            carries: Vec::new(),
            body: Block {
                stmts: vec![Stmt::ForLoop {
                    loop_var: "inner".into(),
                    start: Expr::Const(0),
                    end: Expr::Const(3),
                    carries: Vec::new(),
                    body: Block {
                        stmts: vec![load(address)],
                    },
                }],
            },
        }]);
        ir.optimize_indices().unwrap();
        assert!(ir.body.stmts.iter().any(|s| matches!(
            s,
            Stmt::LetIndex {
                value: Expr::FloorDiv(_, 3),
                ..
            }
        )));
        let outer_body = ir
            .body
            .stmts
            .iter()
            .find_map(|s| {
                if let Stmt::ForLoop { body, .. } = s {
                    Some(body)
                } else {
                    None
                }
            })
            .unwrap();
        assert!(outer_body.stmts.iter().any(|s|matches!(s,Stmt::LetIndex{value: Expr::Mul(a,b),..} if **a==Expr::Const(4) && **b==Expr::Var("outer".into()))));
        let mut offsets = Vec::new();
        execute(&ir.body, &mut HashMap::new(), &mut offsets);
        let expected: Vec<_> = (0..7)
            .flat_map(|outer| (0..3).map(move |inner| 7 / 3 + outer * 4 + inner))
            .collect();
        assert_eq!(offsets, expected);
    }
    #[test]
    fn epilogue_indices_are_defined_after_the_contraction_loop() {
        let address = Expr::BlockIdx(Dim::X) * 7_usize + Expr::ThreadIdx(Dim::X);
        let mut ir = ir(vec![
            Stmt::ForLoop {
                loop_var: "k".into(),
                start: Expr::Const(0),
                end: Expr::Const(2),
                carries: Vec::new(),
                body: Block {
                    stmts: vec![load(Expr::Const(0))],
                },
            },
            load(address.clone()),
            load(address),
        ]);
        ir.optimize_indices().unwrap();
        assert!(matches!(ir.body.stmts[0], Stmt::ForLoop { .. }));
        let mut actual = Vec::new();
        execute(&ir.body, &mut HashMap::new(), &mut actual);
        assert_eq!(actual, [0, 0, 50, 50]);
    }

    #[test]
    fn shares_commuted_addresses_without_capturing_unknown_variables() {
        let a = Expr::BlockIdx(Dim::X);
        let b = Expr::ThreadIdx(Dim::X);
        let mut ir = ir(vec![
            load(a.clone() + b.clone()),
            load(b + a),
            load(Expr::Var("external".into()) + Expr::Const(1)),
        ]);
        ir.optimize_indices().unwrap();
        let loads: Vec<_> = ir
            .body
            .stmts
            .iter()
            .filter_map(|s| {
                if let Stmt::Load { row_offset, .. } = s {
                    Some(row_offset)
                } else {
                    None
                }
            })
            .collect();
        assert_eq!(loads[0], loads[1]);
        assert!(matches!(loads[0], Expr::Var(_)));
        assert!(matches!(loads[2], Expr::Add(..)));
    }
}
